﻿using System;
using System.Windows;

namespace X_Mouse_Controls
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }
}
